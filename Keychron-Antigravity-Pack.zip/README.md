# Keychron Cue para Antigravity ⌨️✨

Controla la iluminación de tu teclado Keychron (K17 Max y modelos QMK/VIA compatibles) automáticamente con las acciones de Google Antigravity.

---

## 🚀 Instalación rápida (1 Clic)

1. **Requisitos:**
   * Tener instalado **Python 3** en Windows (con la casilla *"Add python.exe to PATH"* marcada al instalar).
   * Tener el teclado conectado por **Cable USB** con el interruptor en modo **Cable** (la comunicación Raw HID de luces solo funciona por cable).

2. **Instalación:**
   * Haz doble clic en el archivo **`instalar.bat`**.
   * El instalador instalará la librería necesaria (`hidapi`), copiará los archivos a tu usuario, registrará los hooks de Antigravity y creará el acceso directo en tu Escritorio.

---

## 🎨 Personalización de Luces

Abre el acceso directo en tu Escritorio: **`Configurar Luces Keychron.bat`**

Desde la interfaz gráfica podrás:
* **Probar en vivo:** Haz clic en los botones del Modo 1 al 18 para ver el efecto cambiar instantáneamente en tu teclado.
* **Asignar modos:**
  * 🔨 **Trabajando:** Animación activa mientras Antigravity procesa o ejecuta herramientas.
  * ❓ **Esperando Input:** Señal cuando el asistente te hace una pregunta o pide confirmación.
  * ✅ **Terminado:** Luz de aviso de éxito durante X segundos (configurable de 3 a 60 segundos).
  * 💤 **Reposo:** Modo al que regresa tu teclado después del aviso.
* **Guardar:** Pulsa el botón azul para aplicar los cambios a Antigravity.

---

## 🗑️ Desinstalación
Si en algún momento quieres desactivarlo, solo haz doble clic en **`desinstalar.bat`**.
